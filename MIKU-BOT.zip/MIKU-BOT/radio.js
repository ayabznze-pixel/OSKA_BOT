import { unwatchFile, watchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'
import cheerio from 'cheerio'
import fetch from 'node-fetch'
import axios from 'axios'
import moment from 'moment-timezone'

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •
global.owner = [
'201026910354', 
'201228515386'
]

global.mods = []
global.prems = []

global.gataJadibts = true

global.isBaileysFail = false
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •
global.botNumberCode = ''
global.confirmCode = '' 
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •
global.baileys = '@whiskeysockets/baileys'

global.APIs = {
blackwave: {url: 'https://blackwave-api.vercel.app/api/v1', key: null},
md: {url: 'https://blackwave-api.vercel.app/', key: null}
}
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •
global.cheerio = cheerio
global.fs = fs
global.fetch = fetch
global.axios = axios
global.moment = moment
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

global.packname = '╭ 𝐑𝐀𝐃𝐈𝐎 𝐃𝐄𝐌𝐎𝐍 ✓'
global.author =
'◌°⃟𑁁◌𝑴𝑰𝑲𝑼 𝑩𝑶𝑻°⃟𑁁🎤'

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • 
global.libreria = '@whiskeysockets/baileys'
global.languaje = 'arabic'
global.vs = '2.0.0'
global.nameqr = 'Miku-bot-MD'
global.namebot = '꒰ 🥥 ꒱ؘ ᰔᩚ︎𝙼𝚒𝚔𝚞-𝚋𝚘𝚝ᰔᩚ ࿔*:･ﾟ'
global.Rubysessions = 'Session'
global.jadi = 'jadibts' 
global.RubyJadibts = true
global.vsJB = '5.0 (Beta)'
global.gt = '𝖬𝖨𝖪𝖴 𝖡𝖮𝖳'
global.imagen = fs.readFileSync('./Menu.jpg')

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

global.rg = '⋄┄┄〘 تمت العمليه بنجاح🧸 〙┄┄⋄\n\n'
global.resultado = rg

global.ag = '⋄┄┄〘 معلومه 〙┄┄⋄\n\n'
global.advertencia = ag

global.iig = '⋄┄┄〘 اصبر في معلومه لازم تعرفها🥷🩸 〙┄┄⋄\n\n'
global.informacion = iig

global.fg = '⋄┄┄〘 حصل خطاء يحب🧞‍♂️ 〙┄┄⋄\n\n'
global.fallo = fg

global.mg = '⋄┄┄〘 كده غلط يسطا بتعمل اي🗿 〙┄┄⋄\n\n'
global.mal = mg

global.eeg = '⋄┄┄〘 تحذير🙂 〙┄┄⋄\n\n'
global.envio = eeg

global.eg = '⋄┄┄〘 تمت بنجاح🧞‍♂️🩸 〙┄┄⋄\n\n'
global.exito = eg

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

global.wm = '𝗠𝗶𝗸𝘂-𝙈𝘿 : ♡︎✿︎𝙼𝙸𝙺𝚄 𝙱𝙾𝚃ꨄ︎ఌ'

global.igfg = '𝗠𝗶𝗸𝘂𝘽𝙤𝙩-𝙈𝘿'

global.nomorown = '201026910354'

global.pdoc = [

'application/vnd.openxmlformats-officedocument.presentationml.presentation',

'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',

'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

'application/vnd.ms-excel',

'application/msword',

'application/pdf',

'text/rtf'

]
global.cmenut = '❖––––––『'
global.cmenub = '┊✦ '
global.cmenuf = '╰━═┅═━––––––๑\n'
global.cmenua = '\n⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕\n     '

global.dmenut = '*❖─┅──┅〈*'
global.dmenub = '*┊»*'
global.dmenub2 = '*┊*'
global.dmenuf = '*╰┅────────┅✦*'
global.htjava = '⫹⫺'

global.htki = '*⭑•̩̩͙⊱•••• ☪*'
global.htka = '*☪ ••••̩̩͙⊰•⭑*'

global.comienzo = '• • ◕◕════'
global.fin = ' • •'

global.botdate = `⫹⫺ Date :  ${moment.tz('Africa/Cairo').format('DD/MM/YY')}`
global.bottime = `𝗧 𝗜 𝗠 𝗘 : ${moment.tz('Africa/Cairo').format('HH:mm:ss')}`
global.fgif = {
key: {
participant: '0@s.whatsapp.net'
},
message: {
videoMessage: {
title: wm,
h: 'Hmm',
seconds: '999999999',
gifPlayback: 'true',
caption: bottime,
jpegThumbnail: fs.readFileSync('./icon.jpg')
}
}
}

// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

// IDs de canales
global.ch = {
ch1: '120363404349859805@newsletter',
ch2: '120363404349859805@newsletter',
ch3: '120363404349859805@newsletter',
ch4: '120363404349859805@newsletter',
ch5: '120363404349859805@newsletter',
ch6: '120363404349859805@newsletter',
ch7: '120363404349859805@newsletter',
ch8: '120363404349859805@newsletter',
ch9: '120363404349859805@newsletter',
ch10: '120363404349859805@newsletter',
ch11: '120363404349859805@newsletter',
ch12: '120363404349859805@newsletter',
ch13: '120363404349859805@newsletter',
ch14: '120363404349859805@newsletter',
ch15: '120363404349859805@newsletter',
ch16: '120363404349859805@newsletter',
ch17: '120363404349859805@newsletter',
ch18: '120363404349859805@newsletter',
ch19: '120363404349859805@newsletter',
ch20: '120363404349859805@newsletter',
ch21: '120363404349859805@newsletter',
ch22: '120363404349859805@newsletter'
}
// • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • • •

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
unwatchFile(file)
console.log(chalk.redBright("Update 'config.js'"))
import(`${file}?update=${Date.now()}`)
})

global.yt = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.ig = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.md = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.fb = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.tk = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.ths = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.paypal = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.asistencia = 'https://wa.me/201500564191'
global.all = 'https://www.atom.bio/GataBot'
global.canal1 = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.canal2 = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.canal3 = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'
global.canal4 = 'https://whatsapp.com/channel/0029Vb6qkXM8V0tvdYh1fJ2g'

global.soporteGB = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo1 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo2 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo_collab1 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo_collab2 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo_collab3 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
global.grupo_collab4 = 'https://chat.whatsapp.com/JiCkjOX3ZesGVwg77wDaTj'
