import crypto from "crypto";
import axios from "axios";

/* =======================
   SaveTube Class
======================= */
class savetube {
  constructor() {
    this.ky = "C5D58EF67A7584E4A29F6C35BBC4EB12";
    this.fmt = ["144", "240", "360", "480", "720", "1080", "mp3"];
    this.reg =
      /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;

    this.is = axios.create({
      headers: {
        "content-type": "application/json",
        origin: "https://yt.savetube.me",
        "user-agent":
          "Mozilla/5.0 (Android 15; Mobile) Gecko/130.0 Firefox/130.0",
      },
    });
  }

  async decrypt(enc) {
    const buf = Buffer.from(enc, "base64");
    const key = Buffer.from(this.ky, "hex");
    const iv = buf.slice(0, 16);
    const data = buf.slice(16);
    const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
    return JSON.parse(
      Buffer.concat([decipher.update(data), decipher.final()]).toString()
    );
  }

  async getCdn() {
    const r = await this.is.get(
      "https://media.savetube.vip/api/random-cdn"
    );
    return r.data.cdn;
  }

  async download(url, format) {
    const id = url.match(this.reg)?.[3];
    if (!id) return { status: false };

    const cdn = await this.getCdn();

    const info = await this.is.post(
      `https://${cdn}/v2/info`,
      { url: `https://www.youtube.com/watch?v=${id}` }
    );

    const dec = await this.decrypt(info.data.data);

    const dl = await this.is.post(
      `https://${cdn}/download`,
      {
        id,
        downloadType: format === "mp3" ? "audio" : "video",
        quality: format === "mp3" ? "128" : format,
        key: dec.key,
      }
    );

    return {
      status: true,
      title: dec.title,
      url: dl.data.data.downloadUrl,
    };
  }
}

/* =======================
   Handler
======================= */
const st = new savetube();

let handler = async (m, { command, args, conn }) => {
  if (!args[0]) {
    let txt = `
*╮═≼『⚠️┃خـطـأ┃⚠️』≽═╭*
*┇⌗╎يـرجـى وضـع رابـط يـوتـيـوب*
*╯✯≼══━━﹂⚠️﹁━━══≽✯*

📌 مثال:
.${command} https://youtu.be/xxxx
`;
    return m.reply(txt);
  }

  // تحويل الأوامر
  let format;
  if (command === "m3" || command === "اغنيه") {
    format = "mp3";
  } else {
    format = command;
  }

  let loadingTxt = `
*╮═≼『🎬┃جـاري الـتـحـمـيـل┃⏳』≽═╭*
*┇⌗╎الـجـودة:* ${format === "mp3" ? "MP3 🎧" : format + "p 📽️"}
*┇⌗╎جـاري مـعـالـجـة الـمـلـف...*
*╯✯≼══━━﹂🎬﹁━━══≽✯*
〔 🎭 Freddy Fazbear 〕
`;
  await m.reply(loadingTxt);

  const res = await st.download(args[0], format);

  if (!res.status) {
    let errTxt = `
*╮═≼『❌┃فـشـل┃❌』≽═╭*
*┇⌗╎تـعـذر تـحـمـيـل الـمـلـف*
*╯✯≼══━━﹂❌﹁━━══≽✯*
`;
    return m.reply(errTxt);
  }

  let doneTxt = `
*╮═≼『✅┃تـم الـتـحـمـيـل┃🎉』≽═╭*
*┇⌗╎الاسـم:* ${res.title}
*┇⌗╎الـجـودة:* ${format === "mp3" ? "MP3 🎧" : format + "p 📽️"}
*╯✯≼══━━﹂✅﹁━━══≽✯*
〔 🎭 Freddy Fazbear 〕
`;

  if (format === "mp3") {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: res.url },
        mimetype: "audio/mpeg",
        fileName: `${res.title}.mp3`,
        caption: doneTxt,
      },
      { quoted: m }
    );
  } else {
    await conn.sendMessage(
      m.chat,
      {
        video: { url: res.url },
        caption: doneTxt,
      },
      { quoted: m }
    );
  }
};

handler.command =
  /^(144|240|360|480|720|1080|m3|اغنيه)$/i;

export default handler;