// الكود مقدم من سبيد 3 إكس زد - تم التعريب بواسطة الذكاء الاصطناعي
import { Maker } from "imagemaker.js"

const effects = {
  'شعار_قلب': 'https://en.ephoto360.com/text-heart-flashlight-188.html',
  'شعار_الكريسماس': 'https://en.ephoto360.com/christmas-effect-by-name-376.html',
  'شعار_زوجين': 'https://en.ephoto360.com/sunlight-shadow-text-204.html',
  'شعار_جلتش': 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html',
  'شعار_حزين': 'https://en.ephoto360.com/write-text-on-wet-glass-online-589.html',
  'شعار_جيمنج': 'https://en.ephoto360.com/make-team-logo-online-free-432.html',
  'شعار_وحيد': 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html',
  'شعار_دراغون_بول': 'https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html',
  'شعار_نيون': 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html',
  'شعار_قطتي': 'https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html',
  'شعار_فتاة_جيمر': 'https://en.ephoto360.com/create-cute-girl-gamer-mascot-logo-online-687.html',
  'شعار_ناروتو': 'https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html',
  'شعار_مستقبلي': 'https://en.ephoto360.com/light-text-effect-futuristic-technology-style-648.html',
  'شعار_سحاب': 'https://en.ephoto360.com/cloud-text-effect-139.html',
  'شعار_ملاك': 'https://en.ephoto360.com/angel-wing-effect-329.html',
  'شعار_سماء': 'https://en.ephoto360.com/create-a-cloud-text-effect-in-the-sky-618.html',
  'شعار_جرافيتي_ثلاثي': 'https://en.ephoto360.com/text-graffiti-3d-208.html',
  'شعار_ماتريكس': 'https://en.ephoto360.com/matrix-text-effect-154.html',
  'شعار_رعب': 'https://en.ephoto360.com/blood-writing-text-online-77.html',
  'شعار_أجنحة': 'https://en.ephoto360.com/the-effect-of-galaxy-angel-wings-289.html',
  'شعار_جيش': 'https://en.ephoto360.com/free-gaming-logo-maker-for-fps-game-team-546.html',
  'شعار_ببجي': 'https://en.ephoto360.com/pubg-logo-maker-cute-character-online-617.html',
  'شعار_ببجي_بناتي': 'https://en.ephoto360.com/pubg-mascot-logo-maker-for-an-esports-team-612.html',
  'شعار_لول': 'https://en.ephoto360.com/make-your-own-league-of-legends-wallpaper-full-hd-442.html',
  'شعار_امونج_اس': 'https://en.ephoto360.com/create-a-cover-image-for-the-game-among-us-online-762.html',
  'فيديو_شعار_ببجي': 'https://en.ephoto360.com/lightning-pubg-video-logo-maker-online-615.html',
  'فيديو_شعار_نمر': 'https://en.ephoto360.com/create-digital-tiger-logo-video-effect-723.html',
  'فيديو_مقدمة': 'https://en.ephoto360.com/free-logo-intro-video-maker-online-558.html',
  'فيديو_شعار_جيمنج': 'https://en.ephoto360.com/create-elegant-rotation-logo-online-586.html',
  'شعار_محارب': 'https://en.ephoto360.com/create-project-yasuo-logo-384.html',
  'غلاف_لاعب': 'https://en.ephoto360.com/create-the-cover-game-playerunknown-s-battlegrounds-401.html',
  'غلاف_فري_فاير': 'https://en.ephoto360.com/create-free-fire-facebook-cover-online-567.html',
  'غلاف_ببجي': 'https://en.ephoto360.com/create-facebook-game-pubg-cover-photo-407.html',
  'غلاف_كونتر': 'https://en.ephoto360.com/create-youtube-banner-game-cs-go-online-403.html',
}

const handler = async(m, {conn, command, args})=>{
  if(!args[0]) return m.reply('*[❗] يرجى إدخال نص*')

  try{
    await conn.reply(m.chat, '*جاري إنشاء الشعار، انتظر لحظة... 🕑*', m)
    const maker = new Maker()
    const res = await maker.Ephoto360(effects[command],[args.join(' ')])
    await conn.sendFile(m.chat,res.imageUrl,'sh.png',null,m)
  }catch(e){
    await conn.reply(m.chat,'*خطأ، يرجى المحاولة مرة أخرى 🔖*',m)
  }
}

handler.command = Object.keys(effects)
handler.tags = ['لوجو']
handler.help = Object.keys(effects)

export default handler