const handler = async (m, { conn }) => {
  const imageUrl = "https://files.catbox.moe/e8nf4x.jpg";
  const link1 = "https://wa.me/201500564191";

  // 💫 الرسالة بصورة كبيرة بدون أزرار
  const adMessage = {
    text: `*◞💖‟⌝╎مرحبـاً أنا:  ◡̈⃝𝙼𝚒𝚔𝚞 𝚋𝚘𝚝ꨄ︎ఌ🎀*\n*┊˚₊·͟͟͞͞➳❥مرحبا احبائي انا بوت متعدد المهام مطوري راديو استعمل(.اوامر) لي طلب القائمه*`,
    contextInfo: {
      externalAdReply: {
        title: "𖥔ᰔᩚ︎𝙼𝚒𝚔𝚞 𝚋𝚘𝚝ꨄ︎ఌ⋆｡˚ ",
        body: "BY|RADIO",
        thumbnailUrl: imageUrl,
        mediaType: 1,
        renderLargerThumbnail: true, 
        mediaUrl: link1
      }
    }
  };

  await conn.sendMessage(m.chat, adMessage, { quoted: m });
};

handler.command = /^بوت$/i;

export default handler;