import axios from "axios";
import fs from "fs";
import path from "path";
import AdmZip from "adm-zip";

let handler = async (m, { conn }) => {
  try {
    let text = m.text;

    if (!text.includes("|"))
      return m.reply("⚠️ | صيغة الأمر غير صحيحة.");

    let parts = text.split("|");
    let token = parts[1];
    let repo = parts[2];
    let zipUrl = parts[3] || null;

    if (!token || !repo)
      return m.reply("⚠️ | لم يتم إدخال التوكن أو الريبو.");

    // Private Repo Fix
    const GH_HEADERS = {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28"
    };

    let temp = "./temp-upload";
    if (fs.existsSync(temp)) fs.rmSync(temp, { recursive: true });
    fs.mkdirSync(temp);

    if (zipUrl) {
      m.reply("⏳ | جاري تنزيل ملف ZIP…");

      let zipPath = path.join(temp, "temp.zip");

      let response;
      try {
        response = await axios.get(zipUrl, { responseType: "arraybuffer" });
      } catch {
        return m.reply("❌ | فشل تنزيل ملف ZIP.");
      }

      fs.writeFileSync(zipPath, response.data);

      m.reply("⏳ | جاري فك الضغط…");

      try {
        let zip = new AdmZip(zipPath);
        zip.extractAllTo(temp, true);
      } catch {
        return m.reply("❌ | ملف ZIP تالف.");
      }

      fs.unlinkSync(zipPath);
    } else {
      return m.reply("⚠️ | لا يوجد رابط ZIP.");
    }

    let counter = 0;

    async function uploadFile(filePath, repoPath) {
      let content = fs.readFileSync(filePath, "base64");

      try {
        await axios.put(
          `https://api.github.com/repos/${repo}/contents/${repoPath}`,
          { message: "Auto Upload", content },
          { headers: GH_HEADERS }
        );

        counter++;

      } catch (err) {
        if (err.response?.status === 401)
          return m.reply("❌ | التوكن غير صالح أو ليس لديه صلاحية repo.");
        if (err.response?.status === 404)
          return m.reply("❌ | الريبو Private والصلاحيات غير كافية.");

        return m.reply("❌ | خطأ أثناء رفع الملفات إلى الريبو.");
      }
    }

    async function walk(dir, prefix = "") {
      let files = fs.readdirSync(dir);
      for (let file of files) {
        let full = path.join(dir, file);
        let repoPath = prefix ? `${prefix}/${file}` : file;

        if (fs.lstatSync(full).isDirectory()) {
          await walk(full, repoPath);
        } else {
          await uploadFile(full, repoPath);
        }
      }
    }

    m.reply("⏳ | جاري رفع الملفات…");

    await walk(temp);

    fs.rmSync(temp, { recursive: true });

    m.reply(`✅ | تم الرفع في الريبو الخاص.\n📁 الملفات: ${counter}`);

  } catch (e) {
    console.log(e);
    return m.reply("❌ | خطأ غير متوقع.");
  }
};

handler.command = ["رافع-جيت"];
export default handler;