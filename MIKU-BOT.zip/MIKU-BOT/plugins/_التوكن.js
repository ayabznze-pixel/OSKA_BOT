/*
كود هذا الملف تم إنشاؤه بالكامل بواسطة:
- ReyEndymion (https://github.com/ReyEndymion)
*/

import fs from 'fs'

let handler = async (m, { conn, usedPrefix }, args, command) => {
  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : m.fromMe
    ? conn.user.jid
    : m.sender

  let uniqid = `${who.split`@`[0]}`

  try {
    if (global.conns.push(conn))
      await conn.sendMessage(
        m.chat,
        {
          text:
            usedPrefix +
            'serbot' +
            ' ' +
            Buffer.from(
              fs.readFileSync('./DiabloJadiBot/' + uniqid + '/creds.json'),
              'utf-8'
            ).toString('base64')
        },
        { quoted: m }
      )
  } catch (e) {
    await conn.reply(
      m.chat,
`*╮──────────────────⟢ـ*
*⧉┆✦ لــســت مــن الــبــوتــات الــفــرعــيــة 🪵*
*╯──────────────────⟢ـ*

*╮──────────────────⟢ـ*
*⧉┆↜ لــتــحــويــلــك إلــى ســب-بــوت 🪵*
*⧉┆↜ اســتــخــدم الأمــر ⬳*
*⧉┆↜ ˼ ${usedPrefix}serbot ˹*
*╯──────────────────⟢ـ*

*╮──────────────────⟢ـ*
*⧉┆⚠️ فــي حــالــة مــشــكــلــة فــي الــدخــول*
*⧉┆↜ قــم بــحــذف الــجــلــســة مــن الأجــهــزة*
*⧉┆↜ ثــم اســتــخــدم ⬳*
*⧉┆↜ ˼ ${usedPrefix}eliminarjb ˹*
*╯──────────────────⟢ـ*`,
      m
    )
    if (m.fromMe) return
  }
}

handler.command = /^(التوكن)$/i
handler.group = true   // ← يعمل في الجروبات
// لا يوجد handler.private

export default handler