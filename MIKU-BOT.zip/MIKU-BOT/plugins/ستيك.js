// بواسطة IZANA و Radio
// تابع قناة 𝐀𝐁𝐘𝐒𝐒|𝐂𝐎𝐑𝐄 في واتساب: https://whatsapp.com/channel/0029Vb7B41dLtOjBeD5Fwq2N
// تابع قناة 𝑆𝐻𝛩𝐷𝛩𝑊 𝐵𝛩𝑇 في واتساب: https://whatsapp.com/channel/0029Vb8z64I0wak1S4EBQp1K

import axios from 'axios';
import { createSticker, StickerTypes } from 'wa-sticker-formatter';

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) throw `⚠️ أرسل الكلمة التي تريد البحث عنها وعدد الملصقات.\n\nمثال: *${usedPrefix + command} أنمي 5*`;

  const [query, countInput] = text.split(' ');
  let count = parseInt(countInput) || 5;
  if (count > 30) count = 30;

  await m.react('⌛');
  conn.reply(m.chat, `> ⏳ *جاري البحث عن ${count} صورة وتحويلها لملصقات...*`, m);

  let images = [];
  try {
    const res = await axios.get('https://api-blackwave.vercel.app/api/v1/search/pinterest', {
      params: { query }
    });
    images = res.data?.pins?.map(pin => pin.image).filter(Boolean).slice(0, count);
  } catch (e) {
    console.error(`⚠️ خطأ في API: ${e.message}`);
  }

  if (!images || images.length === 0) {
    await m.react('❌');
    return m.reply(`❌ لم يتم العثور على نتائج لـ *"${query}"*.`);
  }

  for (let i = 0; i < images.length; i++) {
    try {
      const response = await axios.get(images[i], { responseType: 'arraybuffer' });
      const buffer = Buffer.from(response.data);
      const sticker = await createSticker(buffer, {
        type: StickerTypes.CROPPED,
        pack: "Pinterest Pack",
        author: "𝑆𝐻𝛩𝐷𝛩𝑊 𝐵𝛩𝑇",
        quality: 80,
        keepScale: true,
        crop: false
      });
      await conn.sendMessage(m.chat, { sticker }, { quoted: m });
      await new Promise(r => setTimeout(r, 1000));
    } catch (err) {
      console.error(`❌ خطأ في تحويل الصورة رقم ${i + 1}:`, err.message);
      await conn.reply(m.chat, `⚠️ فشل في تحويل الصورة رقم ${i + 1}`, m);
    }
  }

  await m.react('✅');
  await conn.reply(m.chat, `✅ *تم إنشاء ${images.length} ملصق من Pinterest!*`, m);
};

handler.help = ['ستيك <الكلمة> <العدد>'];
handler.tags = ['sticker', 'tools'];
handler.command = /^(ستيك|ستيكرات|استيكرات)$/i;

export default handler;