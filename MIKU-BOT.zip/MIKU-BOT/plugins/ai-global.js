import axios from "axios"

let handler = async function (m, { conn }) {

  if (typeof m.text !== 'string') return

  // تجاهل الأوامر
  const prefix = /^[.!#/$]/
  if (prefix.test(m.text)) return

  const chat = global.db.data.chats[m.chat]
  if (!chat || chat.miku !== true) return

  try {
    let name = m.pushName || "صديقي"

    let prompt = `
أنت ذكاء اصطناعي اسمك ميكو 🎶
أسلوبك كيوت ولطيف.
اسم المستخدم: ${name}

لو حد سألك مين المطور:
قولي: المطور اسمه Radio 🎤

ردّي رد طبيعي على:
${m.text}
`

    let url = `https://api-blackwave.vercel.app/api/v1/ai/gemini?prompt=${encodeURIComponent(prompt)}`
    let res = await axios.get(url)

    let reply = res.data?.response || "مش سامعاك قوي 🥲"

    await conn.sendMessage(
      m.chat,
      { text: reply },
      { quoted: m }
    )

  } catch (e) {
    console.error("MIKU ERROR:", e)
  }
}

handler.before = true
export default handler