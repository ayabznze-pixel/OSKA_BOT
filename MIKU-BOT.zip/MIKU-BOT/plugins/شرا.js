import axios from "axios";
import baileys from "@whiskeysockets/baileys";
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = baileys;

const IMG_URL = "https://files.catbox.moe/rip3zx.jpg"; // صورة ثابتة للباقة
const DEV = "967730201713@s.whatsapp.net"; // رقم المطور

// 🖼️ تجهيز الصورة للواتس
async function createImageMessage(conn, url) {
    try {
        const media = await prepareWAMessageMedia({ image: { url } }, { upload: conn.waUploadToServer });
        return media.imageMessage || null;
    } catch {
        return null;
    }
}

// إرسال باقات البوت مع Carousel
async function sendPackages(conn, m) {
    const imgMessage = await createImageMessage(conn, IMG_URL);

    // الباقات المزخرفة
    const packages = [
        {
            name: "الباقة الأولى",
            desc: `⛄┊≡ ◡̈⃝🧸↜الباقة الأولى  
🎤┊≡ ◡̈⃝🎼↜عدد الأوامر: 100  
❄️┊ ۬.͜ـ🧸˖ ⟨السعر المصري: 100 جنيه | خارج مصر: 3 دولار☇  
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈─๋︩︪─ ∙ ∙ ⊰ـ  
┤─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪─☇ـ  
┤┌  
│┊طرق الدفع:  
│┊- فودافون كاش (يمني فقط)  
│┊- كريمي  
│┊- جيب كاش  
│┊- محفظة كاش  
│┊- Binance  
┤└─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪☇ـ  
⚠️ ملاحظة: يتم الدفع حسب بلدك الطبيعي`,
            id: "الأولى"
        },
        {
            name: "الباقة الثانية",
            desc: `⛄┊≡ ◡̈⃝🧸↜الباقة الثانية  
🎤┊≡ ◡̈⃝🎼↜عدد الأوامر: 500  
❄️┊ ۬.͜ـ🧸˖ ⟨السعر المصري: 250 جنيه | خارج مصر: 6 دولار☇  
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈─๋︩︪─ ∙ ∙ ⊰ـ  
┤─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪─☇ـ  
┤┌  
│┊طرق الدفع:  
│┊- فودافون كاش (يمني فقط)  
│┊- كريمي  
│┊- جيب كاش  
│┊- محفظة كاش  
│┊- Binance  
┤└─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪☇ـ  
⚠️ ملاحظة: يتم الدفع حسب بلدك الطبيعي`,
            id: "الثانية"
        },
        {
            name: "الباقة الكبيرة",
            desc: `⛄┊≡ ◡̈⃝🧸↜الباقة الكبيرة  
🎤┊≡ ◡̈⃝🎼↜عدد الأوامر: 1000  
❄️┊ ۬.͜ـ🧸˖ ⟨السعر المصري: 450 جنيه | خارج مصر: 100 دولار☇  
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈─๋︩︪─ ∙ ∙ ⊰ـ  
┤─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪─☇ـ  
┤┌  
│┊طرق الدفع:  
│┊- فودافون كاش (يمني فقط)  
│┊- كريمي  
│┊- جيب كاش  
│┊- محفظة كاش  
│┊- Binance  
┤└─ׅ─ׅ┈─๋︩︪──ׅ─ׅ┈─๋︩︪☇ـ  
⚠️ ملاحظة: يتم الدفع حسب بلدك الطبيعي`,
            id: "الكبيرة"
        }
    ];

    const cards = packages.map(pkg => ({
        body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🪴 *${pkg.name}*\n${pkg.desc}` }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "طلب البوت فورينا" }),
        header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: !!imgMessage, imageMessage: imgMessage }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [{
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "شراء الآن",
                    id: `.طلب_${pkg.id}`
                })
            }]
        })
    }));

    const carouselMessage = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({ text: "✨ باقات طلب البوت فورينا ✨" }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
                })
            }
        }
    }, {});

    await conn.relayMessage(m.chat, carouselMessage.message, { messageId: carouselMessage.key?.id });
    await m.react("✅");
}

// التعامل مع طلب الباقات → إرسال للمطور
async function handleOrder(conn, m, pkgName) {
    const groupLink = m.isGroup ? `https://chat.whatsapp.com/${m.chat.split("-")[0]}` : "غير متوفر";

    const text = `
📩 تم استلام طلب باقة من المستخدم:

📱 الرقم: ${m.sender.split("@")[0]}
👤 المنشن: @${m.sender.split("@")[0]}
🔗 رابط المجموعة: ${groupLink}
🎁 الباقة: ${pkgName}
    `;

    await conn.sendMessage(DEV, { text, mentions: [m.sender] });
    conn.reply(m.chat, `✅ تم ارسال طلب الشراء\nتواصل مع المطور لتأكيد الطلب`, m);
}

// المعالج الرئيسي
let handler = async (m, { conn, command }) => {
    if (command === "شرا" || command === "طلب البوت") return sendPackages(conn, m);

    if (command.startsWith("طلب_")) {
        const pkg = command.split("_")[1];
        return handleOrder(conn, m, pkg);
    }
};

handler.command = ["شرا", "طلب البوت", "طلب_الأولى", "طلب_الثانية", "طلب_الكبيرة"];
handler.tags = ["info"];
handler.group = true;

export default handler;