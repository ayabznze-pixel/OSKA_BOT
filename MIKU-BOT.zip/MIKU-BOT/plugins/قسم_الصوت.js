import fs from "fs";
import path from "path";
import axios from "axios";

// 🗣️ خريطة الأصوات
const voices = [
  { arName: "ليانا", desc: "صوت أنثوي واضح ومشرق" },
  { arName: "ميرال", desc: "صوت ناعم ودافئ" },
  { arName: "تاليا", desc: "صوت أنثوي مشرق وحيوي" },
  { arName: "رِنا", desc: "صوت لطيف ومهذب" },
  { arName: "سيرين", desc: "صوت ناعم ومتزن" },
  { arName: "فاي", desc: "صوت أنثوي حيوي" },
  { arName: "ياسمين", desc: "صوت راقي وأنيق" },
  { arName: "نوفا", desc: "صوت شاب ومفعم بالحيوية" },
  { arName: "آية", desc: "صوت دافئ وحنون" },
  { arName: "لينا", desc: "صوت بريطاني راقي" },
  { arName: "رودينا", desc: "صوت هادئ ومريح" },
  { arName: "جودي", desc: "صوت احترافي وواضح" },
  { arName: "سلمى", desc: "صوت ناعم ومعبر" },

  { arName: "ريان", desc: "صوت ذكوري متزن" },
  { arName: "جاد", desc: "صوت ذكوري قوي" },
  { arName: "باسل", desc: "صوت عميق وقوي" },
  { arName: "سامي", desc: "صوت وثائقي احترافي" },
  { arName: "رامي", desc: "صوت ذكوري واثق" },
  { arName: "كريم", desc: "صوت دافئ" },
  { arName: "نور", desc: "صوت ودي ولطيف" },
  { arName: "آدمو", desc: "صوت أمريكي متوسط" },
  { arName: "فهد", desc: "صوت ذكوري رسمي" },
  { arName: "دان", desc: "صوت بريطاني شاب" },
  { arName: "ليو", desc: "صوت أمريكي حيوي" },
  { arName: "تيم", desc: "صوت جريء وواثق" },
  { arName: "نزار", desc: "صوت مرح ومتفائل" },
  { arName: "عمر", desc: "صوت عميق ومؤثر" },
  { arName: "كافا", desc: "صوت رجولي هادئ" },
  { arName: "باهر", desc: "صوت ساحر وجذاب" },
  { arName: "هاني", desc: "صوت أمريكي قوي" },
  { arName: "جادسون", desc: "صوت أسترالي هادئ" },
  { arName: "سيف", desc: "صوت بريطاني محترف" },
  { arName: "راكان", desc: "صوت شاب وحيوي" },
  { arName: "مهند", desc: "صوت أمريكي قوي" },
  { arName: "كريمون", desc: "صوت أمريكي جنوبي" },
  { arName: "سندس", desc: "صوت شاب وديناميكي" },
  { arName: "تيمور", desc: "صوت أمريكي شاب" },

  { arName: "زيلان", desc: "صوت مميز من ElevenLabs" },
  { arName: "ناريس", desc: "صوت نسائي معبر" }
];

let handler = async (m, { conn }) => {
    // الحصول على معرف المنشن
    let mentionId = m.key.participant || m.key.remoteJid;

    // قراءة ملف روابط الصور
    const linksFile = './media-links.txt';
    if (!fs.existsSync(linksFile)) return await m.reply('⚠️ ملف روابط الصور غير موجود.');
    const links = fs.readFileSync(linksFile, 'utf-8').split('\n').filter(Boolean);
    if (!links.length) return await m.reply('⚠️ ملف روابط الصور فارغ.');

    // اختيار صورة كبيرة وعشوائية
    const randomIndex = Math.floor(Math.random() * links.length);
    const imageUrl = links[randomIndex];

    // اختيار صورة مصغرة مختلفة
    let thumbUrl;
    if (links.length === 1) thumbUrl = imageUrl;
    else {
        let thumbIndex;
        do {
            thumbIndex = Math.floor(Math.random() * links.length);
        } while (thumbIndex === randomIndex);
        thumbUrl = links[thumbIndex];
    }

    // تحميل الصورة المصغرة
    let thumbnailBuffer;
    try {
        const resp = await axios.get(thumbUrl, { responseType: 'arraybuffer' });
        thumbnailBuffer = Buffer.from(resp.data, 'binary');
    } catch { thumbnailBuffer = null; }

    // تقسيم الأصوات
    const females = voices.filter((_, i) => i < 13).map(v => `*┇🎙️ ${v.arName}* - ${v.desc}`).join("\n");
    const males = voices.filter((_, i) => i >= 13).map(v => `*┇🎙️ ${v.arName}* - ${v.desc}`).join("\n");

    // نص الرسالة المزخرفة
    const message = `*╮═『🎶┃𝐅υׁ𝐫𝐢𝐧𝐚 𝐁ׅ𝗼𝐭┃🎶』═╭*
*┇🏮👋 أهلاً بـ〘@${mentionId.split('@')[0]}〙*
*╮═『🎶┃🗣️ أصوات البوت┃🎶』═╭*
*┇👩‍🎤 أصوات نسائية:*\n${females}\n
*┇👨‍🎤 أصوات رجالية:*\n${males}
*╯✯≼══━━﹂🎶﹁━━══≽✯*
⏤͟͞ू⃪ 𝑭𝒖𝒓𝒊𝒏𝐚🌺⃝𖤐`;

    // إرسال الرسالة مع الصورة والمنشن
    const contactInfo = {
        key: { fromMe: false, participant: m.sender, remoteJid: 'status@broadcast@g.us', id: 'Halo' },
        message: { contactMessage: { displayName: '@' + mentionId.split('@')[0], vcard: `BEGIN:VCARD\nVERSION:3.0\nTEL;waid=${m.sender.split("@")[0]}:${m.sender.split("@")[0]}\nEND:VCARD` } },
        participant: m.sender
    };

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: message,
        mentions: [m.sender],
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                title: '⏤͟͞ू⃪ 𝐅υׁ𝐫𝐢𝐧𝐚-𝐁ׅ𝗼𝐭🌸⃝𖤐',
                body: '@' + mentionId.split('@')[0],
                thumbnail: thumbnailBuffer,
                mediaType: 2,
                mediaUrl: 'https://whatsapp.com/channel/0029Vb7B41dLtOjBeD5Fwq2N',
                showAdAttribution: true,
                renderLargerThumbnail: false
            }
        }
    }, { quoted: contactInfo });
};

handler.command = /^(قسم_audio_ai)$/i;
handler.exp = 50;
handler.fail = null;
export default handler;