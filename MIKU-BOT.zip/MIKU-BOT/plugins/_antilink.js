// ╮═『🎶┃𝐀𝐍𝐓𝐈-𝐋𝐈𝐍𝐊 𝐁𝐎𝐓┃🎶』═╭
// 🏮 نظام حماية الجروبات من الروابط غير المصرح بها
// ╯✯≼══━━﹂🎶﹁━━══≽✯

const linkRegex = /(chat\.whatsapp\.com\/[0-9A-Za-z]{20,24})|(z?https:\/\/whatsapp\.com\/channel\/[0-9A-Za-z]{20,24})/i
const allowedLinks = ['https://whatsapp.com/channel/0029Vb7B41dLtOjBeD5Fwq2N']

export async function before(m, { conn, isAdmin, isBotAdmin, isROwner, participants }) {
    if (!m.isGroup) return
    if (!m || !m.text) return

    const chat = global?.db?.data?.chats[m.chat]
    const isGroupLink = linkRegex.test(m.text)
    const isChannelLink = /whatsapp\.com\/channel\//i.test(m.text)
    const hasAllowedLink = allowedLinks.some(link => m.text.includes(link))

    // ╮═『🎶┃🌐 الروابط المسموح بها┃🎶』═╭
    if (hasAllowedLink) return
    // ╯✯≼══━━﹂🎶﹁━━══≽✯

    if ((isGroupLink || isChannelLink) && !isAdmin) {
        // ╮═『🎶┃💻 تحقق البوت┃🎶』═╭
        if (isBotAdmin) {
            const linkThisGroup = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`
            if (isGroupLink && m.text.includes(linkThisGroup)) return !0
        }
        // ╯✯≼══━━﹂🎶﹁━━══≽✯

        // ╮═『🎶┃🚨 Anti-Link فعال┃🎶』═╭
        if (chat.antilink && isGroupLink && !isAdmin && !isROwner && isBotAdmin && m.key.participant !== conn.user.jid) {
            // حذف الرسالة
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            })

            // تنبيه المجموعة بالعضو المخالف
            await conn.reply(m.chat,
                `*╮═『🎶┃🚫 Anti-Link ┃🎶』═╭*\n` +
                `┇🏮⚠️ ║ تم إزالة *${global.db.data.users[m.key.participant].name || 'المستخدم'}* من الجروب\n` +
                `┇🏮❌ ║ السبب: نشر رابط غير مسموح به\n` +
                `┇🏮🔗 ║ النوع: ${isChannelLink ? 'رابط قناة' : 'رابط جروب آخر'}\n` +
                `*╯✯≼══━━﹂🎶﹁━━══≽✯*`
            )

            // طرد العضو من الجروب
            await conn.groupParticipantsUpdate(m.chat, [m.key.participant], 'remove')
        }
        // ╯✯≼══━━﹂🎶﹁━━══≽✯
    }
}